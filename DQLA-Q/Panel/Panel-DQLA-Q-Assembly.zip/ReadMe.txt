These files contain the necessary information to assemble a PCB.

Board Name: Panel, DQLA-Q Board, Rev 1.1
Release Date: 01/23/2023

The files included are:
1-  ReadME.txt             This file
2-  Panel-DQLA-Q.GTP       Top side paste stencil
3-  Panel-DQLA-Q-ODB.zip   Board in OBD Format
4-  DQLA-Q-PnP.txt         Pick And Place File (Single board only)

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Apertures in the paste mask are the same size as the PCB pads for most pads.
   Large pads are windowed.

3) There are no surface mount components on the bottom side of the board.

4) The BOM file is provided separately.
